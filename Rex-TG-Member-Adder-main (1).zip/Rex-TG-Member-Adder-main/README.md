# 🇷‌🇪‌🇽‌ 1.0
<p align='center'><b>Cross Platform Telegram Members Scraping and Adding Toolkit</b></p>

# 🇺‌🇸‌🇦‌🇬‌🇪‌ 👨‍🔧

* You need to install requirements first - `pip install -r requirements.txt`
* Then you need to store your accounts using `rexmanager.py`
* Then, scrape and add members using `rexadder.py`

<b> For full tutorial, refer to <a href='https://github.com/krish775/Rex-TG-Member-Adder/blob/main/how_to_use.txt'>how_to_use.txt</a> </b>

# 🇫‌🇪‌🇦‌🇹‌🇺‌🇷‌🇪‌🇸‌ 🔥

* No need of API Id and API hash- It requires only phone numbers
* Adds 60 members on an average
* Adds members by ID, even if they don't have usernames.
* Multi-session adding 
* Adds members in high speed[Stable]
* Adds to private/public groups
* Scrapes members from private/public groups
* Cross platform- Works in Android[Termux], Linux, Windows, etc

# 🇸‌🇨‌🇷‌🇪‌🇪‌🇳‌🇸‌🇭‌🇴‌🇹‌ 📷
<p align='center'><img src='https://github.com/krish775/Rex-TG-Member-Adder/blob/main/Screenshot_20210814-153259_Termux.png' width='720' height='1520'></p>
